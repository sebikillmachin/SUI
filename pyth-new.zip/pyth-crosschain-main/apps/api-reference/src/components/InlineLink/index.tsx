import { Styled } from "../Styled";

export const InlineLink = Styled(
  "a",
  "font-medium text-pythpurple-600 hover:underline dark:text-pythpurple-400",
);
