import { Styled } from "../Styled";

export const MaxWidth = Styled("div", "mx-auto px-8");
