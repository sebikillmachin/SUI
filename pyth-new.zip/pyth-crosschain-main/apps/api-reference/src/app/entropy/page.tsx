export { Entropy as default } from "../../components/Entropy";
