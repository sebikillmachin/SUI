"use client";

export { Error as default } from "../components/Error";
