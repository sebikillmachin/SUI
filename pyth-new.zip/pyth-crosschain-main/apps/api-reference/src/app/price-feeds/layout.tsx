import type { Metadata } from "next";

export { PriceFeeds as default } from "../../components/PriceFeeds";

export const metadata: Metadata = {
  title: "Price Feeds",
};
