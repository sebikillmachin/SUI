export { NotFound as default } from "../components/NotFound";
