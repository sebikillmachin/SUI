export { Home as default } from "../components/Home";
