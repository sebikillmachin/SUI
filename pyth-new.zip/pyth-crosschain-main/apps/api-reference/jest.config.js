import { defineJestConfigForNextJs } from "@pythnetwork/jest-config/define-next-config";

export default defineJestConfigForNextJs();
