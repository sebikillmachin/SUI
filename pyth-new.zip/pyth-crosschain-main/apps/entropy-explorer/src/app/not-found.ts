export { NotFoundPage as default } from "@pythnetwork/component-library/NotFoundPage";
