export { Root as default } from "../components/Root";
export { metadata, viewport } from "../metadata";
