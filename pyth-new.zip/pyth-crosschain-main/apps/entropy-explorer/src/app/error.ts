"use client";

export { ErrorPage as default } from "@pythnetwork/component-library/ErrorPage";
