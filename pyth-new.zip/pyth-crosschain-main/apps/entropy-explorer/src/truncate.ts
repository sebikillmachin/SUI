export const truncate = (value: string) =>
  `${value.slice(0, 6)}...${value.slice(-4)}`;
