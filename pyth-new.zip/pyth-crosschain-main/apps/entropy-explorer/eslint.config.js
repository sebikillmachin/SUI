export { nextjs as default } from "@cprussin/eslint-config";
