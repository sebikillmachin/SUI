class StaleConnectionError(Exception):
    pass


class PushError(Exception):
    pass
