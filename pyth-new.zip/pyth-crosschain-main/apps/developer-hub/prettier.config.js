export { base as default } from "@cprussin/prettier-config";
