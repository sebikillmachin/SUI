export const FORTUNA_API_URLS = {
  mainnet: "https://fortuna.dourolabs.app/v1/chains/configs",
  testnet: "https://fortuna-staging.dourolabs.app/v1/chains/configs",
} as const;
